package mx.tecnm.tepic.ladm_u1_practica2_archivomemoriainternayexterna

import android.content.Intent
import android.graphics.Color
import android.opengl.ETC1.getWidth
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.view.marginLeft
import androidx.core.view.marginTop
import kotlinx.android.synthetic.main.activity_main2.*
import java.io.*
import kotlin.math.max

class MainActivity2 : AppCompatActivity() {
    var titu: String = ""
    var contenido: String = ""
    var nombArchivo: String = ""
    var archivos = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        agregar.setOnClickListener() {
            //crearNuevaNota()

            var agregar = Intent(this, MainActivity3::class.java)
            //agregar.putExtra("abiertos",archivos)
            startActivity(agregar)
        }//agregar------------------------------------------

        abrir.setOnClickListener() {

            abrirNota()
        }//abrir---------------------------------------------

        borrar.setOnClickListener(){
            borrarArchivo()
        }//borrar-------------------------------
    }

    fun llenar(ignorar:String): Boolean{
        if(deleteFile(ignorar)) {
            gridContenido.removeAllViews()
            archivos.remove(ignorar)
            var cantidad = archivos.count() - 1
            if(cantidad != 0) {
                for (i in 0..cantidad) {
                    leer(archivos.get(i))
                }//for
                Toast.makeText(this, "Se ha borrado con exito", Toast.LENGTH_LONG)
                    .show()

            }
            return true
        }//if
        else{

            return false
        }
    }//llenar interna----------------------------------------------------------------------------------

    fun generartextView() {
        val campoTexto = EditText(this)
        campoTexto.setBackgroundColor(Color.LTGRAY)
        campoTexto.setPadding(40, 40, 40, 40)
        campoTexto.setText(titu + "\n" + contenido)
        gridContenido.setPadding(0,15,0,0)
        gridContenido.addView(campoTexto)

    }//generarTextView-----------------------------------------------------------------------------

    fun abrirNota() {
        val buscar = EditText(this)
        buscar.inputType = InputType.TYPE_CLASS_TEXT
        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage("Escriba Nombre Archivo")
            .setView(buscar)
            .setPositiveButton("AGREGAR") { d, i ->
                nombArchivo = buscar.text.toString()+".txt"
                if (leer(nombArchivo)==false){
                    AlertDialog.Builder(this)
                        .setTitle("ERROR!")
                        .setMessage("No encontrado en memoria interna, Buscando en SD...")
                        .setNegativeButton("ACEPTAR") { dialog, i ->
                            dialog.cancel()
                            leerExt(nombArchivo)
                        }

                        .show()

                }

            }
            .setNegativeButton("CANCELAR") { d, i ->
                d.cancel()
            }
            .show()
    }//abrirNota--------------------------------------------------------------------------------

    fun leer(nombre:String): Boolean {
        try {
            val archivo = BufferedReader(InputStreamReader(openFileInput(nombre)))
            titu = archivo.readLine()
            contenido = archivo.readLine()
            archivo.close()
            generartextView()
            archivos.add(nombre)
            return true
        } catch (io: IOException) {

            return false
        }
    }//leer---------------------------------------------------------------------------------------

    fun borrarArchivo() {
        val nomArcBorrar = EditText(this)
        nomArcBorrar.inputType = InputType.TYPE_CLASS_TEXT
        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage("Escriba Nombre Archivo a Borrar en memoria INTERNA")
            .setView(nomArcBorrar)
            .setPositiveButton("ACEPTAR") { d, i ->
                var nombreArchivoBorrar = nomArcBorrar.text.toString()+".txt"
               /// val source = File(nombreArchivoBorrar)
                //source.delete()
                if(llenar(nombreArchivoBorrar)==false){
                    borrarArchivoExt()
                }
            }
            .setNegativeButton("CANCELAR") { d, i ->
                d.cancel()
            }
            .show()
    }//borrarArchivo-------------------------------------------------------------------------------
    //------------------------FUNCIONES PARA ABRIR Y BORRAR ARCHIVOS EXTERNOS----------------------------
    fun leerExt(nombre:String): Boolean {



            try {
                val sd = getExternalFilesDir(null)
                val file = File(sd?.absolutePath, nombre)

                val archivo = BufferedReader(FileInputStream(file).bufferedReader())
                titu = archivo.readLine()
                contenido = archivo.readLine()
                archivo.close()
                generartextView()
                archivos.add(nombre)
                return true
            } catch (io: IOException) {
                AlertDialog.Builder(this)
                    .setTitle("ERROR!")
                    .setMessage("No se encontro el archivo")
                    .setNegativeButton("ACEPTAR") { dialog, i ->
                        dialog.cancel()
                    }
                    .show()
                return false

            }
    }//leer externa---------------------------------------------------------------------------------------

    fun borrarArchivoExt() {
        val nomArcBorrar = EditText(this)
        nomArcBorrar.inputType = InputType.TYPE_CLASS_TEXT
        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage("Escriba Nombre Archivo a Borrar en memoria EXTERNA")
            .setView(nomArcBorrar)
            .setPositiveButton("ACEPTAR") { d, i ->
                var nombreArchivoBorrar = nomArcBorrar.text.toString()+".txt"
                /// val source = File(nombreArchivoBorrar)
                //source.delete()
                try {
                    gridContenido.removeAllViews()
                    val sd = getExternalFilesDir(null)
                    val file = File(sd?.absolutePath, nombreArchivoBorrar)
                    val deleted: Boolean = file.delete()
                    AlertDialog.Builder(this)
                        .setTitle("Borrado con exito")
                        .setNegativeButton("ACEPTAR") { dialog, i ->
                            dialog.cancel()
                        }
                        .show()
                } catch (io: IOException) {
                    AlertDialog.Builder(this)
                        .setTitle("ERROR!")
                        .setMessage("No se encontro el archivo o no se pudo borrar")
                        .setNegativeButton("ACEPTAR") { dialog, i ->
                            dialog.cancel()
                        }
                        .show()


                }
            }
            .setNegativeButton("CANCELAR") { d, i ->
                d.cancel()
            }
            .show()
    }//borrarArchivo externa-------------------------------------------------------------------------------
}


