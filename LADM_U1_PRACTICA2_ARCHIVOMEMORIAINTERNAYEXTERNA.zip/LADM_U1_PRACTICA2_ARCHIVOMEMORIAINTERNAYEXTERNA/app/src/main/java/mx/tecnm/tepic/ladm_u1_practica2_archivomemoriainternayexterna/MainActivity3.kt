package mx.tecnm.tepic.ladm_u1_practica2_archivomemoriainternayexterna

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main3.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter

class MainActivity3 : AppCompatActivity() {
    var nombreArchivo: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        cancelar.setOnClickListener() {
            finish()
        }//cancelar

        aceptar.setOnClickListener() {
            nombreArchivo()
        }//aceptar

    }

        fun nombreArchivo() {
            val nomArc = EditText(this)
            nomArc.inputType = InputType.TYPE_CLASS_TEXT
            AlertDialog.Builder(this)
                .setTitle("ATENCION")
                .setMessage("Escriba Nombre Archivo")
                .setView(nomArc)
                .setPositiveButton("AGREGAR") { d, i ->
                    nombreArchivo = nomArc.text.toString()
                    ubicacion()
                }
                .setNegativeButton("CANCELAR") { d, i ->
                    d.cancel()
                }
                .show()
        }//nomArchivo--------------------------------------------------------------------------

    fun ubicacion(){
        var interna = findViewById<RadioButton>(R.id.interno).isChecked()
        var externa = findViewById<RadioButton>(R.id.externo).isChecked()
        if(interna){
            guardarEnArchivoInterno()
        }else if(externa){
            guardarEnArchivoExterno()
        }
    }//ubicacion--------------------------------------------------------------------------------

    private fun guardarEnArchivoInterno(): Boolean {
        try {
            var textoTitulo = findViewById<EditText>(R.id.titulo).text.toString()
            var textocontenido = findViewById<EditText>(R.id.nota).text.toString()
            //TAREA COMO CONSTRUIR ARCHIVOS EXTERNOS EN MEMORIA SD
            val archivo = OutputStreamWriter(openFileOutput(nombreArchivo + ".txt", MODE_PRIVATE))
            var textoAGuardar = textoTitulo + "\n" + textocontenido

            archivo.write(textoAGuardar) //hace el guardado de datos  en archivo
            archivo.flush()// forza a guardar  en este momento
            archivo.close() //se cierra para evitar alteraciones
            Toast.makeText(this, "Se guardo con exito", Toast.LENGTH_LONG)
                .show()
            finish()
            //generartextView(textoTitulo,textocontenido)
            return true;
        } catch (io: IOException) {
            AlertDialog.Builder(this)
                .setTitle("ATENCION!M ERROR")
                .setMessage(io.message)
                .setPositiveButton("ACEPTAR") { dialog, exception ->
                    dialog.dismiss()
                }
                .show()
            return false;
        }
    }//guardarEnArchivoInterno--------------------------------------------------------------------------------

    private fun guardarEnArchivoExterno(): Boolean {

      try {
          var textoTitulo = findViewById<EditText>(R.id.titulo).text.toString()
          var textocontenido = findViewById<EditText>(R.id.nota).text.toString()
          var textoAGuardar = textoTitulo + "\n" + textocontenido

       val sd = getExternalFilesDir(null)
        val file = File(sd?.absolutePath, nombreArchivo+".txt")
        val osw = OutputStreamWriter(FileOutputStream(file))
        osw.write(textoAGuardar)

        osw.flush()
        osw.close()
        Toast.makeText(this,"Los datos fueron guardados correctamente",Toast.LENGTH_LONG).show()
        finish()
        return true;
      }catch (io: IOException){
          AlertDialog.Builder(this)
              .setTitle("No se pudo Guardar")
              .setMessage(io.message)
              .setPositiveButton("ACEPTAR") { dialog, exception ->
                  dialog.dismiss()
              }
              .show()
          return false;
      }
        }

}